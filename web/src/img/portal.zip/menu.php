<?php
include "_scripts/functions.php";
perfil($login);
?>
<div>
  <img src="_images/mitra.png" class="img-fluid" alt="Responsive image">
    <div>
        <nav class="navbar navbar-inverse" style="margin-top: 10px;padding: 0px;">
            <div class="container-fluid" style="padding: 0px">
            <ul class="menu nav navbar-nav"> 
              <?php if(perfil($login)=="ADM"){ ?>
                <li class="menuItem mt-2 active"><a href="dados_gerais.php"><i class="mr-2 fas fa-home"></i>Início</a></li>
                <li class="menuItem mt-2"><a href="cad_categoria.php"><i class="fas fa-align-justify mr-2"></i>Categorias</a></li>
                <li class="menuItem mt-2"><a href="cadastro.php"><i class="fas fa-list mr-2"></i>Tópico</a></li>
                <li class="menuItem mt-2" ><a href="_input/index.php"><i class="fas fa-plus mr-2"></i>Add user</a></li>
                <li class="menuItem mt-2"><a href="index.php"><i class="fas fa-sign-out-alt mr-2"></i>Sair</a></li>
              <?php }else{ ?>
                <li class="active"><a href="dados_gerais.php">Início</a></li>
                <li><a href="index.php"></a></li>
              <?php } ?>
            </ul>
           
<form class="navbar-form navbar-left" action="busca.php" style="margin-top: 15px">
       <div class="input-group">
  <input type="text" class="form-control" required placeholder="Buscar" aria-label="Recipient's username" aria-describedby="basic-addon2">
  <div class="input-group-append">
    <button class="btn btn-outline-primary" type="submit"><i class="fas fa-search"></i></button>
  </div>
</div>
          </div>
        </nav>
    </div>
</div>

</form>
