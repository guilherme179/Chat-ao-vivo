<?php
session_start();
?>
<!doctype html>
<html lang="pt">
<head>
<link rel="stylesheet" href="_css/boot.css">
<link rel="stylesheet" href="_css/login.css">
<link rel="stylesheet" href="_css/select2.css">
<link rel="stylesheet" href="_css/all.css">


  <title>Mitra Portal</title>
</head>
<body style="background: url('_images/wallpaper.png');
  background-size: cover;" >
<!------ Include the above in your HEAD tag ---------->
  <div class="wrapper fadeInDown">
    <div id="formContent">
      <!-- Tabs Titles -->

      <!-- Icon -->
      <br>
      <div class="fadeIn first">
        <img style="heigth:60%; width:40%; margin-right:100px;" src="_images/mitra.png" id="icon" alt="User Icon" />
      </div>
      
      <br>
      <h6>Seja bem vindo ao sistema Mitra!</h6>

      <!-- Login Form -->
      <form method="post" action="v2/login.php">
        <div >
          <i class="far fa-user" ></i>
          <!-- <select style="background-color: #ebedf0;" > -->
          <select name="cod_cidade" id="cidade" class="fadeIn second" required data-placeholder="Pick your choice" data-tabindex="1">
            <?php
              include_once "_scripts/config.php";
              $query = mysqli_query($conn, "SELECT nome_cidade, cod_cidade FROM u748436382_portal_mitra.cidades order by nome_cidade ASC");
              while($dado = $query->fetch_array()){
            ?>
              <option value="<?php echo $dado['cod_cidade']?>"><?php echo $dado['nome_cidade'] ?></option>
            <?php } ?>
  
          </select>
        </div>
        
        <div >
          <i class="far fa-user" ></i>
            <input style="background-color: #ebedf0;" type="text" id="login_claro" class="fadeIn second" name="login_claro" placeholder="Login claro.." required>
        </div>
        
        <div >
          <i class="far fa-user" ></i>
            <input style="background-color: #ebedf0;" type="text" id="login" class="fadeIn second" name="usuario" placeholder="Acesso.." required>
        </div>      

        <!-- <div class="input-group-prepend">
          <div class="input-group-text"><i class="far fa-user"></i><input style="background-color: #ebedf0;" type="text" id="login" class="fadeIn second" name="usuario" placeholder="Login" required></div>
        </div>  -->

       <div>
        <i class="fas fa-key"></i>
        <input  style="background-color: #ebedf0;" type="password" id="password" class="fadeIn third" name="senha" placeholder="Senha de acesso..">
      </div>
      
        <br>
        <input type="submit" class="fadeIn fourth" value="Acessar" name="enviar">
      </form>

      <!-- Remind Passowrd 
      <div id="formFooter">
        <a class="underlineHover" data-toggle="modal" data-target="#exampleModal">Esqueceu sua senha?</a> | 
        <a class="underlineHover" data-toggle="modal" data-target="#exampleModal2">Alterar senha</a>
      </div>

    </div>
  </div>





<!- - Modal Resetar Senha - ->
<form method="post" action="">
  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">INFORME SEU E-MAIL</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body" style="color: #000;font-size: 14px;width: 100% !important">

          <div class="form-group row">
            <label for="inputEmail3" class="col-sm-2 col-form-label" style="vertical-align: middle;line-height: 30px">E-MAIL:</label>
            <div class="col-sm-10">
              <input type="email" class="form-control" name="email2" required>
            </div>
          </div>

          <div class="form-group row">
            <div class="col-sm-12" style="margin:0 auto;text-align: center">
              <input type="submit" class="btn btn-primary" value="Resetar Senha" name="enviar2">
            </div>
          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal">Fechar</button>
        </div>
      </div>
    </div>
  </div>
</form>
<!- - FIM MODAL - ->



<!- - Modal Alterar Senha - ->
<form method="post" action="">
  <div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">ALTERAR SENHA </h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body" style="color: #000;font-size: 14px;width: 100% !important">

          <div class="form-group row">
            <label for="inputEmail3" class="col-sm-2 col-form-label" style="vertical-align: middle;line-height: 30px">E-MAIL:</label>
            <div class="col-sm-10">
              <input type="email" class="form-control" name="email3" required>
            </div>
          </div>

          <div class="form-group row">
            <label for="inputEmail3" class="col-sm-2 col-form-label" style="vertical-align: middle;line-height: 30px">Senha Atual:</label>
            <div class="col-sm-10">
              <input type="password" class="form-control" name="senha_ant" required>
            </div>
          </div>

          <div class="form-group row">
            <label for="inputEmail3" class="col-sm-2 col-form-label" style="vertical-align: middle;line-height: 30px">Nova Senha:</label>
            <div class="col-sm-10">
              <input type="password" class="form-control" name="nova_senha" required>
            </div>
          </div>

          <div class="form-group row">
            <div class="col-sm-12" style="margin:0 auto;text-align: center">
              <input type="submit" class="btn btn-primary" value="Atualizar Senha" name="enviar3">
            </div>
          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal">Fechar</button>
        </div>
      </div>
    </div>
  </div>
</form>
<!- - FIM MODAL - ->

-->





<script src="_js/jquery.js"></script>
<script src="_js/bundle.js"></script>
<script src="_js/sw.js"></script>
<script src="_js/select2.min.js"></script>
<script src="_js/login.js"></script>

</body>
</html>


<?php

if(isset($_POST['enviar'])){
include "_scripts/config.php";

$login = $_POST['login'];
$senha = md5($_POST['senha']);


    $sql = "SELECT login FROM login WHERE login = '$login'";//VERIFICAMOS SE O LOGIN EXISTE
    $query = $mysqli->query($sql);
    $total = $query->num_rows;
    if($total>=1){//CASO O LOGIN EXISTA, VERIFICAMOS A SENHA

      $sql2 = "SELECT login,senha FROM login WHERE login = '$login' AND senha = '$senha'";//VERIFICAMOS SE O LOGIN EXISTE
      $query2 = $mysqli->query($sql2);
      $total2 = $query2->num_rows;

      if($total2>=1){//CASO LOGIN E SENHA ESTEJAM OK

        $_SESSION['login'] = $login;
    
        echo "<script type='text/javascript'>
          window.location='dados_gerais.php';
          </script>";

      }else{//CASO O LOGIN ESTEJA OK E SENHA NÃO SEJA VALIDADA ?>

        <script language='javascript'>
         swal({ 
           icon:"error",
           text: "Ops! Sua senha está incorreta.",
           type: "success"}).then(okay => {
             if (okay) {
              window.location.href = "index.php";
            }
          });
        </script>     
      
      <?php }

    }else{//CASO O LOGIN NÃO EXISTA ?>

      <script language='javascript'>
       swal({ 
         icon:"error",
         text: "Ops! Esse login não consta em nossa base de dados.",
         type: "success"}).then(okay => {
           if (okay) {
            window.location.href = "index.php";
          }
        });
      </script>


    <?php } 

   

}





if(isset($_POST['enviar3'])){//ATUALIZAR SENHA
include "_scripts/config.php";

$login = $_POST['email3'];
$senha_ant = md5($_POST['senha_ant']);
$nova_senha = md5($_POST['nova_senha']);


    $sql = "SELECT login FROM login WHERE login = '$login'";//VERIFICAMOS SE O LOGIN EXISTE
    $query = $mysqli->query($sql);
    $total = $query->num_rows;

    if($total>=1){//CASO O LOGIN EXISTA, VERIFICAMOS A SENHA

      $sql2 = "SELECT login,senha FROM login WHERE login = '$login' AND senha = '$senha_ant'";//VERIFICAMOS SE O LOGIN EXISTE
      $query2 = $mysqli->query($sql2);
      $total2 = $query2->num_rows;

      if($total2>=1){//CASO LOGIN E SENHA ESTEJAM OK

        $sql3 = "UPDATE login SET senha = '$nova_senha' WHERE login = '$login'";//VERIFICAMOS SE O LOGIN EXISTE
        $query3 = $mysqli->query($sql3);
      ?>


      <script language='javascript'>
         swal({ 
           icon:"success",
           text: "Senha atualizada com sucesso!",
           type: "success"}).then(okay => {
             if (okay) {
              window.location.href = "index.php";
            }
          });
        </script>  

        

      <?php }else{//CASO O LOGIN ESTEJA OK E SENHA NÃO SEJA VALIDADA ?>

        <script language='javascript'>
         swal({ 
           icon:"error",
           text: "Ops! Sua senha está incorreta.",
           type: "success"}).then(okay => {
             if (okay) {
              window.location.href = "index.php";
            }
          });
        </script>     
      
      <?php }

    }else{//CASO O LOGIN NÃO EXISTA ?>

      <script language='javascript'>
       swal({ 
         icon:"error",
         text: "Ops! Esse login não consta em nossa base de dados.",
         type: "success"}).then(okay => {
           if (okay) {
            window.location.href = "index.php";
          }
        });
      </script>


    <?php } 

   

}




if(isset($_POST['enviar2'])){//ENVIAR E-MAIL DE RESET

include "_scripts/config.php";

$email = $_POST['email2'];
$at_senha = mt_rand();
$at = md5($at_senha);


    $sql = "SELECT login FROM login WHERE login = '$email'";//VERIFICAMOS SE O LOGIN EXISTE
    $query = $mysqli->query($sql);
    $total = $query->num_rows;

    if($total>=1){//CASO O LOGIN EXISTA, ENVIAMOS O E-MAIL

      $sql = "UPDATE login SET senha = '$at' WHERE login = '$email'";//atualizamos uma nonha senha e mandamos para o usuário
      $query = $mysqli->query($sql);



        //DADOS DO E-MAIL

        // Inclui o arquivo class.phpmailer.php localizado na mesma pasta do arquivo php 
        include "_scripts/mail/PHPMailerAutoload.php"; 
         
        // Inicia a classe PHPMailer 
        $mail = new PHPMailer(); 
         
        // Método de envio 
        $mail->IsSMTP(); 
         
        // Enviar por SMTP 
        $mail->Host = "email.tel.inf.br"; 
         
        // Você pode alterar este parametro para o endereço de SMTP do seu provedor 
        $mail->Port = 26; 
         
         
        // Usar autenticação SMTP (obrigatório) 
        $mail->SMTPAuth = true; 
         
        // Usuário do servidor SMTP (endereço de email) 
        // obs: Use a mesma senha da sua conta de email 
        $mail->Username = 'suportemitra@tel.inf.br'; 
        //$mail->Password = '08fOWPeC'; 
        $mail->Password = '@ZEEdrQpBAU'; 
         
        // Configurações de compatibilidade para autenticação em TLS 
        $mail->SMTPOptions = array( 'ssl' => array( 'verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true ) ); 
         
        // Você pode habilitar esta opção caso tenha problemas. Assim pode identificar mensagens de erro. 
        // $mail->SMTPDebug = 2; 
         
        // Define o remetente 
        // Seu e-mail 
        $mail->From = "suportemitra@tel.inf.br"; 
         
        // Seu nome 
        $mail->FromName = "MITRA - Intranet"; //TITULO DA MENSAGEM
         
        // Define o(s) destinatário(s) 
        $mail->AddAddress($email, $nome); //PARA QUEM ESTÁ SENDO ENVIADO
        //$mail->AddAddress('laleluia@tel.inf.br', 'Larissa'); //PARA QUEM ESTÁ SENDO ENVIADO
         
        // Opcional: mais de um destinatário
        // $mail->AddAddress('fernando@email.com'); 
         
        // Opcionais: CC e BCC
         //$mail->AddCC('ecarmo@tel.inf.br', $nome); 
        // $mail->AddBCC('roberto@gmail.com', 'Roberto'); 
         
        // Definir se o e-mail é em formato HTML ou texto plano 
        // Formato HTML . Use "false" para enviar em formato texto simples ou "true" para HTML.
        $mail->IsHTML(true); 
         
        // Charset (opcional) 
        $mail->CharSet = 'UTF-8'; 
         
        // Assunto da mensagem 
        $mail->Subject = "Reset de Senha"; 
         
        // Corpo do email 
        $mail->Body = '
          <table style="font-size:12px;font-family:verdana" cellpadding="5" cellspace="10">
            <tr>
              <td>
                <b>Oi '.$email.'</b>,
              </td>
            </tr>
            <tr> 
              <td>
                Sua senha foi resetada para '.$at_senha.'.<br>
                Acesse o sistema e clique em alterar senha para atualizar para alterar.
              </td>
            </tr>

            <tr>
              <td><img src="cid:logo_2u" width="60%" height="20%"></td>
            </tr>

              
           </table>
          ';
     
        $mail->AddEmbeddedImage('_images/ass_mail.png', 'logo_2u'); 
         
        // Opcional: Anexos 
        // $mail->AddAttachment("/home/usuario/public_html/documento.pdf", "documento.pdf"); 
         
        // Envia o e-mail 
        $enviado = $mail->Send(); 
         
        // Exibe uma mensagem de resultado 
        if ($enviado) { ?>
            

          <script language='javascript'>
           swal({ 
             icon:"success",
             text: "Reset realizado com sucesso! Instruções enviadas por e-mail",
             type: "success"}).then(okay => {
               if (okay) {
                window.location.href = "index.php";
              }
            });
          </script>



        <?php } else { 
            echo "Houve um erro enviando o email: ".$mail->ErrorInfo; 
        }

    }else{//CASO O LOGIN NÃO EXISTA ?>

      <script language='javascript'>
       swal({ 
         icon:"error",
         text: "Ops! Esse login não consta em nossa base de dados.",
         type: "success"}).then(okay => {
           if (okay) {
            window.location.href = "index.php";
          }
        });
      </script>


    <?php } 

   

}



?>

<script src="_js/all.js">
</script>






