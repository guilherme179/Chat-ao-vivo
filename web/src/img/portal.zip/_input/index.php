<?php 
include "../_scripts/config.php";
date_default_timezone_set("America/Fortaleza");

if(isset($_POST['Enviar'])){

    if ($_FILES[csv][size] > 0) {
    //mysql_query("TRUNCATE indicadores;");
        //get the csv file
        $file = $_FILES[csv][tmp_name];
        $handle = fopen($file,"r");
       // $rs["obs_feedback"] = utf8_decode(htmlspecialchars_decode($rs["obs_feedback"]));    

        
        //loop through the csv file and insert into database 
        do {
            if ($data[0]) {
                $data_sistema=date('Y-m-d H:i:s');
                $hora=date('H:i:s');
                mysql_query("INSERT INTO login (
                        login,
                        senha,
                        tipo
                        ) VALUES (
                        
                        '".utf8_encode(addslashes($data[0]))."',
                        '".md5($data[1])."',
                        '".utf8_encode(addslashes($data[2]))."'
                    )
                ");
            }
        } while ($data = fgetcsv($handle,1000,";","'"));
        //

        //redirect
        echo "<script language='javascript'>
            alert('Clientes imputados com sucesso')
            window.location='../painel.php';
            </script>";

    }

}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Input RV</title>
</head>

<body style="font-family: arial">

<?php if (!empty($_GET[success])) { echo "<b>Your file has been imported.</b><br><br>"; } //generic success notice ?>

<form action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
<input type="hidden" name="login" value="<?php echo $_GET['login']; ?>">
  Selecione a base <strong>.CSV</strong> para IMPUT<br />
  <br />
  
  <input name="csv" type="file" id="csv" />
  <input name="Enviar" type="submit" id="Enviar" value="Enviar" />
</form>

<br><br>
<b>Campos FOrm:</b><br>
  <ul>
    <li>Login</li>
    <li>Senha</li>
    <li>Perfil (ADM / CLIENTE)</li>
</ul>

</body>
</html> 
