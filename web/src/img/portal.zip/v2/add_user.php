<?php include "head.php" ?>
<body data-spy="scroll" data-target=".fixed-top">
    
<?php include "menu.php"; 


if($user[1]==0){

  echo "<script language='javascript'>
  alert('Ops! Você não tem acesso a esse conteúdo.')
  window.location='../index.php';  
 </script>";

}?>



    <!-- Header -->
    <header id="header" class="header">
        <div class="header-content">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12"> 
                     
                        <div class="card">
                            <div class="card-body">
                            <h2><span class="turquoise">Cadastre um Usuário:</span> </h2> 

                            <form method="post" action="">

                                <div class="form-group">
                                    <label for="exampleFormControlSelect1">E-mail:</label>
                                    <input type="email" class="form-control" name="email" placeholder="E-mail" required>
                                </div>

                                <div class="form-group">
                                    <label for="exampleFormControlSelect1">Nome:</label>
                                    <input type="text" class="form-control" name="nome" placeholder="Nome" required>
                                </div>

                                <div class="form-group">
                                    <label for="exampleFormControlSelect1">Senha:</label>
                                    <input type="text" class="form-control" name="senha" placeholder="Senha" required>
                                </div>
                                
                                <input class="btn btn-outline-primary" type="submit" value="Cadastrar" name="Cadastrar">
                                <br> <br>  
                            
                            </form>

                            

                </div>
                </div>
                <br> <br>   
                <a class="btn-outline-reg back" href="pesquisar.php">VOLTAR</a>

                <br>

                                                       
                        
                </div> <!-- end of row -->
            </div> <!-- end of container -->
        </div> <!-- end of header-content -->
    </header> <!-- end of header -->
    <!-- end of header -->  


    <?php include "footer.php" ?>
    
    
    <!-- Scripts -->
    <script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
    <script src="js/popper.min.js"></script> <!-- Popper tooltip library for Bootstrap -->
    <script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
    <script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
    <script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
    <script src="js/jquery.magnific-popup.js"></script> <!-- Magnific Popup for lightboxes -->
    <script src="js/validator.min.js"></script> <!-- Validator.js - Bootstrap plugin that validates forms -->
    <script src="js/scripts.js"></script> <!-- Custom scripts -->

</body>
</html>


<?php

if(isset($_POST['Cadastrar'])){

include_once("config.php");

    $email = $_POST["email"];
    $nome = $_POST["nome"];
    $senha = $_POST["senha"];

    $sql = "INSERT INTO  usuario1 (usuario,nome,senha) VALUES ('$email','$nome','$senha')";

    if (mysqli_query($conn, $sql)) {
    echo "<script>alert('Dados cadastrados!'); window.location = 'principal.php';</script>";

    }else{
     echo "Deu erro: " . $sql . "<br>" . mysqli_error($conn);
    }



}


?>

