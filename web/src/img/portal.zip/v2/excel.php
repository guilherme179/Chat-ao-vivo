<?php
session_start();
$login = $_SESSION['login'];
include "_scripts/functions.php";
$user = dadosUser($login);

if($user[1]==0 && $login <> 'staff_claro'){

  echo "<script language='javascript'>
  alert('Ops! Você não tem acesso a esse conteúdo.')
  window.location='../index.php';  
 </script>";

} else {
	
	header("Content-Type: text/html; charset=utf-8'");
	header("Content-type: application/vnd.ms-excel");
	header("Content-type: application/force-download");
	header("Content-Disposition: attachment; filename=relatorio_acesso.xls");
	header("Pragma: no-cache");
	
	
	include "config.php";
	
	if(isset($_POST['data_inicio']) && isset($_POST['data_fim'])){
		$data_inicio = $_POST["data_inicio"];
		$data_fim = date("Y-m-d H:i:s", strtotime($_POST["data_fim"] . " 23:59:59"));
	
		echo "<table border='1'>";
		echo "<tr>";
		echo "<td>id</td>";
		echo "<td>data_acesso</td>";
		echo "<td>login</td>";
		echo "<td>login_claro</td>";
		echo "<td>cidade</td>";
		echo "<td>regional</td>";
	
		echo "</tr>";
	
		$sql = "SELECT *
						FROM u748436382_portal_mitra.contador
						WHERE login <> '' AND data_acesso BETWEEN '$data_inicio' AND '$data_fim';";
		$query = $conn->query($sql);
	
		while ($rs = $query->fetch_array()) {
	
					echo "<td>" . $rs["id"] . "</td>";
					echo "<td>" . $rs["data_acesso"] . "</td>";
					echo "<td>" . $rs["login"] . "</td>";
					echo "<td>" . $rs["login_claro"] . "</td>";
					echo "<td>" . $rs["cidade"] . "</td>";
					echo "<td>" . $rs["regional"] . "</td>";
					
	
		echo "</tr>";
	
		}
	}
}

?>