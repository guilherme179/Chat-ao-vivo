<?php
session_start();
$mysqli = new mysqli("156.67.72.201","u748436382_portal_m","Devmis@1","u748436382_portal_mitra");

if(isset($_POST['usuario']) && isset($_POST['senha']) && isset($_POST['cod_cidade']) && isset($_POST['login_claro'])){

    $usuario = $_POST['usuario'];
    $senha = $_POST['senha'];
    $cod_cidade = $_POST['cod_cidade'];
    $login_claro = $_POST['login_claro'];
    
    $result = $mysqli -> query("SELECT * FROM usuario1 WHERE usuario = '$usuario' AND senha = '$senha';");
    $num = mysqli_num_rows($result);
    
    if($num == 1){       
        
        $sql = "SELECT nome_cidade, regiao_cidade FROM u748436382_portal_mitra.cidades WHERE cod_cidade = $cod_cidade;";
        $result = $mysqli-> query($sql);

        $row = $result -> fetch_array(MYSQLI_NUM);

        $insertContador = "INSERT INTO contador (login, data_acesso, login_claro, cidade, regional) VALUES ('$usuario', date_add(now(), interval -3 hour), '$login_claro', '$row[0]', '$row[1]');";
        $resultContador = $mysqli-> query($insertContador);

        if(resultContador){
            $_SESSION['login'] = $usuario;
            echo '<script type="text/javascript">window.location = "principal.php" </script>';
        }else{
            echo '<script type="text/javascript"> alert("Dados incorretos!"); window.location = "../index.php" </script>';
        }
        
    }
    else{
        echo '<script type="text/javascript"> alert("Dados incorretos!"); window.location = "../index.php" </script>';
    }
} else {
    echo '<script type="text/javascript"> alert("Dados incorretos!"); window.location = "../index.php" </script>';
}

?>