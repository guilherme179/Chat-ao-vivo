<?php include "head.php" ?>
<body data-spy="scroll" data-target=".fixed-top">
    
<?php include "menu.php"; 


if($user[1]==0){

  echo "<script language='javascript'>
  alert('Ops! Você não tem acesso a esse conteúdo.')
  window.location='../index.php';  
 </script>";

}?>



    <!-- Header -->
    <header id="header" class="header">
        <div class="header-content">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12"> 
                     
                        <div class="card">
                            <div class="card-body">
                            <h2><span class="turquoise">Cadastre um Tópico:</span> </h2> 

                            <form method="post" action="" enctype="multipart/form-data">

                                <div class="form-group">
                                    <label for="exampleFormControlSelect1">Categoria</label>
                                    <select class="form-control" name="categoria" required>
                                        <option value="">-</option>
                                        <?php
                                              include "_scripts/config.php";
                                              $sql = "SELECT * FROM categoria   ORDER BY categoria ASC";
                                              $query = $conn->query($sql);
                                                while ($dados = $query->fetch_array()) {
                                                echo '<option value="' . utf8_encode($dados['id']) . '">' .$dados['categoria'] . '</option>';
                                              }
                                        ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Título</label>
                                    <input type="text" class="form-control"  name="pergunta" placeholder="Digite o Título" required>
                                </div>

                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Em quantos dias o tópico deve expirar?</label>
                                    <select id="cp24" class="form-control" name="qtde_dias" required>                                      
                                      <option value="1">1</option>
                                      <option value="2">2</option>
                                      <option value="3">3</option>
                                      <option value="4">4</option>
                                      <option value="5">5</option>
                                      <option value="6">6</option>
                                      <option value="7">7</option>
                                      <option value="8">8</option>
                                    </select>
                                    
                                </div>
                                
                                <div class="form-group">
                                    <label for="exampleFormControlTextarea1">Texto</label>
                                    <textarea class="form-control" rows="3" name="resposta" placeholder="Digite um texto" required></textarea>
                                </div>
                                

                                <div class="form-group">
                                    <div class="col-sm-10">
                                        <input type="file"class="btn btn-primary" id="inputArquivo" name="arquivo">
                                    </div>
                                </div>

                                <input class="btn btn-outline-primary" type="submit" value="Cadastrar" name="Cadastrar">
                                <br> <br>  

                                <input type="hidden" name="login" value="<?php echo $login; ?>">
                            
                            </form>

                            

                </div>
                </div>
                <br> <br>   
                <a class="btn-outline-reg back" href="pesquisar.php">VOLTAR</a>

                <br>

                                                       
                        
                </div> <!-- end of row -->
            </div> <!-- end of container -->
        </div> <!-- end of header-content -->
    </header> <!-- end of header -->
    <!-- end of header -->  


    <?php include "footer.php" ?>
    
    
    <!-- Scripts -->
    <script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
    <script src="js/popper.min.js"></script> <!-- Popper tooltip library for Bootstrap -->
    <script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
    <script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
    <script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
    <script src="js/jquery.magnific-popup.js"></script> <!-- Magnific Popup for lightboxes -->
    <script src="js/validator.min.js"></script> <!-- Validator.js - Bootstrap plugin that validates forms -->
    <script src="js/scripts.js"></script> <!-- Custom scripts -->

</body>
</html>


<?php

if(isset($_POST['Cadastrar'])){

include_once("config.php");

    $pergunta= $_POST["pergunta"];
    $resposta = $_POST["resposta"];
    $categoria = $_POST["categoria"];
    $qtde_dias = $_POST["qtde_dias"];
    $login = $_POST["login"];



     //TRATATIVA DA IMAGEM

        // Pasta onde o arquivo vai ser salvo
      $_UP['pasta'] = 'uploads/';

      // Tamanho máximo do arquivo (em Bytes)
      $_UP['tamanho'] = 1024 * 1024 * 2*1024; // 2Mb

      // Array com as extensões permitidas
      $_UP['extensoes'] = array('jpg', 'png', 'gif', 'xls', 'xlsx', 'docx','doc', 'pdf');

      // Renomeia o arquivo? (Se true, o arquivo será salvo como .jpg e um nome único)
      $_UP['renomeia'] = false;

      // Array com os tipos de erros de upload do PHP
      $_UP['erros'][0] = 'Não houve erro';
      $_UP['erros'][1] = 'O arquivo no upload é maior do que o limite do PHP';
      $_UP['erros'][2] = 'O arquivo ultrapassa o limite de tamanho especifiado no HTML';
      $_UP['erros'][3] = 'O upload do arquivo foi feito parcialmente';
      $_UP['erros'][4] = 'Não foi feito o upload do arquivo';

      
      if($_FILES['arquivo']['error']==4){

        $nome_final = "";

      }else{



        // Verifica se houve algum erro com o upload. Se sim, exibe a mensagem do erro
        if ($_FILES['arquivo']['error'] != 0) {
          die("Não foi possível fazer o upload, erro:" . $_UP['erros'][$_FILES['arquivo']['error']]);
          exit; // Para a execução do script
        }

        // Caso script chegue a esse ponto, não houve erro com o upload e o PHP pode continuar

        // Faz a verificação da extensão do arquivo
        $extensao = strtolower(end(explode('.', $_FILES['arquivo']['name'])));
        if (array_search($extensao, $_UP['extensoes']) === false) {
          echo "Por favor, envie arquivos com as seguintes extensões: jpg, png ou gif";
          exit;
        }

        // Faz a verificação do tamanho do arquivo
        if ($_UP['tamanho'] < $_FILES['arquivo']['size']) {
          echo "O arquivo enviado é muito grande, envie arquivos de até 2Mb.";
          exit;
        }

        // O arquivo passou em todas as verificações, hora de tentar movê-lo para a pasta

        // Primeiro verifica se deve trocar o nome do arquivo
        if ($_UP['renomeia'] == true) {
          // Cria um nome baseado no UNIX TIMESTAMP atual e com extensão .jpg
          $nome_final = md5(time()).'.jpg';
        } else {
          // Mantém o nome original do arquivo
          $nome_final = $_FILES['arquivo']['name'];
        }


         if (move_uploaded_file($_FILES['arquivo']['tmp_name'], $_UP['pasta'] . $nome_final)) {
          // Upload efetuado com sucesso, exibe uma mensagem e um link para o arquivo

          //echo "Upload efetuado com sucesso!";
          // echo '<a href="' . $_UP['pasta'] . $nome_final . '">Clique aqui para acessar o arquivo</a>';
        } else {
          // Não foi possível fazer o upload, provavelmente a pasta está incorreta
          //$a = 1;
        }

    }




    $sql = "INSERT INTO perguntas (pergunta,resposta,categoria,arquivo, qtde_dias,login) VALUES ('$pergunta', '$resposta','$categoria','$nome_final', '$qtde_dias','$login')";

    if (mysqli_query($conn, $sql)) {
    echo "<script>alert('Dados cadastrados!'); window.location = 'cadastro.php';</script>";

    }else{
     echo "Deu erro: " . $sql . "<br>" . mysqli_error($conn);
    }



}


?>

