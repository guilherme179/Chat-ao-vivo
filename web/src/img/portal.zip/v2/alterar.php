<?php include "head.php" ?>
<body data-spy="scroll" data-target=".fixed-top">
    
<?php include "menu.php" ?>

<?php

if($user[1]==0){

  echo "<script language='javascript'>
  alert('Ops! Você não tem acesso a esse conteúdo.')
  window.location='index.php';  
 </script>";

}?>

    <!-- Header -->
    <header id="header" class="header">
        <div class="header-content">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">  
                        <div class="card">
                            <div class="card-body">                           
                            
                                <h2><span class="turquoise">Altere os Dados:</span> </h2>

                                <?php
                                $id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
                                $alt = dadosAlterar($id);
                                ?>
                                
                                <form method="POST" action="">

                                    <input type="hidden" name="id" value="<?php echo $alt[0]; ?>">
                                    
                                    <div class="form-group">
                                    <input type="text" class="form-control" id="categoria" name="categoria" value="<?php echo $alt[1] ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleFormControlInput1">Pergunta</label>
                                        <input type="text" class="form-control" name="pergunta" value="<?php echo $alt[2] ?>">
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="exampleFormControlTextarea1">Resposta</label>
                                        <textarea class="form-control" id="resposta" name="resposta" rows="3" > <?php echo $alt[3] ?>"</textarea>
                                    </div>

                                    <input class="btn btn-outline-primary" type="submit" name="Salvar" value="Salvar">
                                    <br> <br> 

                                </form>
                            </div>
                        </div>
                        <br> <br>
                     <a class="btn-outline-reg back" href="principal.php">VOLTAR</a>

                        
                </div> <!-- end of row -->

            </div> <!-- end of container -->
        </div> <!-- end of header-content -->
    </header> <!-- end of header -->
    <!-- end of header -->


    <?php include "footer.php" ?>
    
    
    <!-- Scripts -->
    <script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
    <script src="js/popper.min.js"></script> <!-- Popper tooltip library for Bootstrap -->
    <script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
    <script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
    <script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
    <script src="js/jquery.magnific-popup.js"></script> <!-- Magnific Popup for lightboxes -->
    <script src="js/validator.min.js"></script> <!-- Validator.js - Bootstrap plugin that validates forms -->
    <script src="js/scripts.js"></script> <!-- Custom scripts -->
    <script src="js/sw.js"></script> <!-- Custom scripts -->


</body>
</html>


<?php

if(isset($_POST['Salvar'])){

include_once("config.php");

    $id = filter_input(INPUT_POST, 'id', FILTER_SANITIZE_NUMBER_INT);
    $pergunta = filter_input(INPUT_POST, 'pergunta', FILTER_SANITIZE_STRING);
    $resposta = filter_input(INPUT_POST, 'resposta', FILTER_SANITIZE_STRING);
    $categoria = filter_input(INPUT_POST, 'categoria', FILTER_SANITIZE_STRING);

    $sql = "UPDATE perguntas SET pergunta='$pergunta', resposta='$resposta', categoria='$categoria', modified=CURRENT_DATE WHERE id='$id'";
    $query = $conn->query($sql);

    if($query){
        echo "<script>alert('Dados atualizados!'); window.location = 'principal.php';</script>";

    }else{
     echo "Deu erro: <br>" . mysqli_error($conn);
    }



}


?>