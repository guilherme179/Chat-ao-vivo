<?php
session_start();
include_once("config.php");

$pergunta= $_POST["pergunta"];
$resposta = $_POST["resposta"];
$categoria = $_POST["categoria"];

mysqli_select_db($conn,'$dbname');

$sql = "INSERT INTO perguntas (pergunta,resposta,categoria) VALUES ('$pergunta', '$resposta','$categoria', '$qtde_dias')";

if (mysqli_query($conn, $sql)) {
echo "<script>alert('Dados cadastrados!'); window.location = 'principal.php';</script>";

}else{
 echo "Deu erro: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>
