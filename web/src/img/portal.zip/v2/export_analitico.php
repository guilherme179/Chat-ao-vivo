<?php
session_start();
$login = $_SESSION['login'];
include "_scripts/functions.php";
$user = dadosUser($login);

if($user[1]==0 && $login <> 'staff_claro'){

  echo "<script language='javascript'>
  alert('Ops! Você não tem acesso a esse conteúdo.')
  window.location='../index.php';  
 </script>";

} else {

header("Content-Type: text/html; charset=utf-8'");
header("Content-type: application/vnd.ms-excel");
header("Content-type: application/force-download");
header("Content-Disposition: attachment; filename=relatorio_perguntas.xls");
header("Pragma: no-cache");


include "config.php";

//VARIÁVEIS RECEBIDAS DO USUÁRIO
if(isset($_POST['data_inicio']) && isset($_POST['data_fim'])){
	$data_inicio = $_POST["data_inicio"];
	$data_fim = date("Y-m-d H:i:s", strtotime($_POST["data_fim"] . " 23:59:59"));

	echo "<table border='1'>";
	echo "<tr>";
	//*******************CAMPOS COMUNS A TODOS OS FORMULÁRIOS******************************************
	echo "<td>id</td>";
	echo "<td>data_input</td>";
	echo "<td>pergunta</td>";
	echo "<td>resposta</td>";
	echo "<td>categoria</td>";
	echo "<td>Login</td>";
	echo "</tr>";


	$sql = "	SELECT u748436382_portal_mitra.perguntas.*,
						u748436382_portal_mitra.categoria.categoria as cat
						from u748436382_portal_mitra.perguntas
						left join u748436382_portal_mitra.categoria on u748436382_portal_mitra.categoria.id = u748436382_portal_mitra.perguntas.categoria
						WHERE u748436382_portal_mitra.perguntas.data_input BETWEEN '$data_inicio' AND '$data_fim'
	;";
	$query = $conn->query($sql);
	while ($rs = $query->fetch_array()){


	echo "<tr>";
	echo "<td>" . $rs["id"] . "</td>";
	echo "<td>" . $rs["data_input"] . "</td>";
	echo "<td>" . $rs["pergunta"] . "</td>";
	echo "<td>" . $rs["resposta"] . "</td>";
	echo "<td>" . $rs["cat"] . "</td>";
	echo "<td>" . $rs["login"] . "</td>";


	echo "</tr>";
	//$i++; contador n utilizado
	}


	echo "</table>";
} else {
	echo "<table border='1'>";
	echo "<tr>";
	//*******************CAMPOS COMUNS A TODOS OS FORMULÁRIOS******************************************
	echo "<td>id</td>";
	echo "<td>data_input</td>";
	echo "<td>pergunta</td>";
	echo "<td>resposta</td>";
	echo "<td>categoria</td>";
	echo "<td>Login</td>";
	echo "</tr>";

	echo "<tr>";
	echo "<td> erro </td>";
	echo "<td> erro </td>";
	echo "<td> erro </td>";
	echo "<td> erro </td>";
	echo "<td> erro </td>";
	echo "<td> erro </td>";

	echo "</tr>";
}
}

