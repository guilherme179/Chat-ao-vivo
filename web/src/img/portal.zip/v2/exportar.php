<?php include "head.php" ?>
<body data-spy="scroll" data-target=".fixed-top">
    
<?php include "menu.php"; 


if($user[1]==0 && $login <> 'staff_claro'){

  echo "<script language='javascript'>
  alert('Ops! Você não tem acesso a esse conteúdo.')
  window.location='../index.php';  
 </script>";

}?>



    <!-- Header -->
    <header id="header" class="header">
        <div class="header-content">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12"> 
                     
                        <div class="card">
                            <div class="card-body">
                            <h2><span class="turquoise">Exporte aqui os dados de acesso:</span> </h2> 

                            <form method="post" action="excel.php">

                                <div class="form-group">
                                    <label for="exampleFormControlSelect1">Data de inicio</label>
                                    <input type="date" class="form-control" name="data_inicio" required>
                                </div>
                                
                                <div class="form-group">
                                    <label for="exampleFormControlSelect1">Data de fim</label>
                                    <input type="date" class="form-control" name="data_fim" required>
                                </div>
                                
                                <input class="btn btn-outline-primary" type="submit" value="Exportar" name="Exportar_acessos">
                                <br> <br>  
                            
                            </form>

                            

                </div>
                </div>
                <br> <br>    
                     
                        <div class="card">
                            <div class="card-body">
                            <h2><span class="turquoise">Exporte aqui os dados de publicações:</span> </h2> 

                            <form method="post" action="export_analitico.php">

                                <div class="form-group">
                                    <label for="exampleFormControlSelect1">Data de inicio</label>
                                    <input type="date" class="form-control" name="data_inicio" required>
                                </div>
                                
                                <div class="form-group">
                                    <label for="exampleFormControlSelect1">Data de fim</label>
                                    <input type="date" class="form-control" name="data_fim" required>
                                </div>
                                
                                <input class="btn btn-outline-primary" type="submit" value="Exportar" name="Exportar_perguntas">
                                <br> <br>  
                            
                            </form>

                            

                </div>
                </div>
                <br> <br>    
                </div> <!-- end of row -->
            </div> <!-- end of container -->
        </div> <!-- end of header-content -->
    </header> <!-- end of header -->
    <!-- end of header -->  


    <?php include "footer.php" ?>
    
    
    <!-- Scripts -->
    <script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
    <script src="js/popper.min.js"></script> <!-- Popper tooltip library for Bootstrap -->
    <script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
    <script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
    <script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
    <script src="js/jquery.magnific-popup.js"></script> <!-- Magnific Popup for lightboxes -->
    <script src="js/validator.min.js"></script> <!-- Validator.js - Bootstrap plugin that validates forms -->
    <script src="js/scripts.js"></script> <!-- Custom scripts -->

</body>
</html>


<?php
?>