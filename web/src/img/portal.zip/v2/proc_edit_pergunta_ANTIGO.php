<?php
session_start();
include_once("config.php");
/*
$id = filter_input(INPUT_POST, 'id', FILTER_SANITIZE_NUMBER_INT);
$pergunta = filter_input(INPUT_POST, 'pergunta', FILTER_SANITIZE_STRING);
$resposta = filter_input(INPUT_POST, 'resposta', FILTER_SANITIZE_STRING);
$categoria = filter_input(INPUT_POST, 'categoria', FILTER_SANITIZE_STRING);

$result_pergunta = "UPDATE perguntas SET pergunta='$pergunta', resposta='$resposta', categoria='$categoria', modified=NOW() WHERE id='$id'";
$resultado_pergunta = mysqli_query($conn, $result_pergunta);

if(mysqli_affected_rows($conn)){
	echo "<script>alert('Dados atualizados!'); window.location = 'principal.php';</script>";

}else{
 echo "Deu erro: <br>" . mysqli_error($conn);
}
mysqli_close($conn);
*/
?>
