<?php include "head.php" ?>

<?php include "menu.php" ?>
<body>
 <!-- Header -->
 <header id="header" class="header">
        <div class="header-content">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12"> 
                   
					<?php
                        
                        if(empty($_POST['pesquisar'])){

                        $pesquisar = "";

                        }else{						
						  $pesquisar = $_POST['pesquisar'];
                        }
						
                        $sql = "SELECT 
                        perguntas.*, 
                        categoria.categoria as cat
                        FROM perguntas
                        LEFT JOIN categoria ON categoria.id = perguntas.categoria
                        WHERE pergunta LIKE '%$pesquisar%'
                        AND date(data_input) + INTERVAL qtde_dias DAY >= CURRENT_DATE";
						$query = $conn->query($sql);
                        $total = $query->num_rows;
                        if($total>=1){
						
    						while($rows_pergunta = mysqli_fetch_array($query)){
                            $dataPost = str_replace("/", "-", $rows_pergunta["data_input"]);
                            $dataCerto = date('d-m-Y H:s', strtotime($dataPost));
                                echo'<div class="card">
                                <div class="card-body">  
                                    <h6>Data do post <span class="badge badge-secondary">'.$dataCerto.'</span></h6>   
                                    <h6> Categoria: '.$rows_pergunta["cat"].'<h6>	
                                    <h3>'.$rows_pergunta["pergunta"].'</h3>							
                                    <p>'.$rows_pergunta["resposta"].'</p>';
                                    $mystring = $rows_pergunta["arquivo"];
                                    $findme   = 'jpg';
                                    $findme2   = 'png';
                                    $pos = strpos($mystring, $findme);
                                    $pos2 = strpos($mystring, $findme2);

                                    if($pos === false and $pos2 === false){

                                    echo '<p> <a href="uploads/'.$rows_pergunta["arquivo"].'" target="_blank"><img src="images/doc.png" width="60px" height="50px"></a></p> <hr>'; 
                                    
                                    }else{

                                        echo '<p> <a href="uploads/'.$rows_pergunta["arquivo"].'" target="_blank"><img src="uploads/'.$rows_pergunta["arquivo"].'" width="200px" height="150px"></a></p> <hr>'; 
                                    }

                                    if($user[1]==1 or $user[1]==2){

                                    echo' <a class="btn btn-outline-warning" href="alterar.php?id='. $rows_pergunta['id'] .'">Alterar</a>'; 
                                }

                                if($user[1]==1){
                                    echo    '<a class="btn btn-outline-danger" onclick="confirmExclusao()" href="proc_apagar_pergunta.php?id='. $rows_pergunta['id'] .'">Excluir</a>'; 
                                    
                                    }


                                    echo '</div>
                                    </div>
                                        <br><br><br> 
                                        ';
        					}
                                

                        }else{

                           echo'
                                <div class="card-body" style="margin-bottom=30px">                            
                                    <h6>Não existem resultados para essa consulta<h6> 
                                </div>';

                        }						
					?>
                    
                    <a class="btn-outline-reg back" href="principal.php">VOLTAR</a>
                
            </div> <!-- end of container -->
        </div> <!-- end of header-content -->
    </header> <!-- end of header -->
    <!-- end of header -->
                
               

</body>
<!-- Scripts -->
    <script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
    <script src="js/popper.min.js"></script> <!-- Popper tooltip library for Bootstrap -->
    <script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
    <script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
    <script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
    <!--<script src="js/jquery.magnific-popup.js"></script>  Magnific Popup for lightboxes -->
    <script src="js/validator.min.js"></script> <!-- Validator.js - Bootstrap plu
    gin that validates forms -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    
    <script src="js/jquery.js"></script>
    <!--<script src="js/scripts.js"></script>  Custom scripts -->
    <script src="js/sweetalert.js"></script> <!-- Custom scripts -->

</html>



