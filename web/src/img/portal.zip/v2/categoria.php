<?php include "head.php" ?>
<body data-spy="scroll" data-target=".fixed-top">
    
<?php include "menu.php"; 


if($user[1]==0){

  echo "<script language='javascript'>
  alert('Ops! Você não tem acesso a esse conteúdo.')
  window.location='../index.php';  
 </script>";

}?>



    <!-- Header -->
    <header id="header" class="header">
        <div class="header-content">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12"> 
                     
                        <div class="card">
                            <div class="card-body">
                            <h2><span class="turquoise">Cadastre uma Categoria:</span> </h2> 

                            <form method="post" action="">

                                <div class="form-group">
                                    <label for="exampleFormControlSelect1">Categoria</label>
                                    <input type="text" class="form-control" name="categoria" placeholder="Digite a categoria" required>
                                </div>
                                
                                <input class="btn btn-outline-primary" type="submit" value="Cadastrar" name="Cadastrar">
                                <br> <br>  
                            
                            </form>

                            

                </div>
                </div>
                <br> <br>  


                <a class="btn-outline-reg back" href="pesquisar.php">VOLTAR</a>

                <br><br><br>
                     
                        <div class="card">
                            <div class="card-body">
                            <h2><span class="turquoise">Exclua uma Categoria</span> </h2> 

                            <form method="post" action="">

                                <div class="form-group">
                                    <label for="exampleFormControlSelect1">Ao deletar, os tópicos associados não aparecem mais.</label>
                                    <select class="form-control" name="categoria" required>
                                        <option value="">-</option>
                                        <?php
                                              include "_scripts/config.php";
                                              $sql = "SELECT * FROM categoria   ORDER BY categoria ASC";
                                              $query = $conn->query($sql);
                                                while ($dados = $query->fetch_array()) {
                                                echo '<option value="' . utf8_encode($dados['id']) . '">' .$dados['categoria'] . '</option>';
                                              }
                                        ?>
                                    </select>
                                </div>
                                
                                <input class="btn btn-outline-danger" type="submit" value="Deletar" name="Deletar">
                                <br> <br>  
                            
                            </form>

                            

                </div>
                </div>
                <br> <br> 

                                                       
                        
                </div> <!-- end of row -->
            </div> <!-- end of container -->
        </div> <!-- end of header-content -->
    </header> <!-- end of header -->
    <!-- end of header -->  


    <?php include "footer.php" ?>
    
    
    <!-- Scripts -->
    <script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
    <script src="js/popper.min.js"></script> <!-- Popper tooltip library for Bootstrap -->
    <script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
    <script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
    <script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
    <script src="js/jquery.magnific-popup.js"></script> <!-- Magnific Popup for lightboxes -->
    <script src="js/validator.min.js"></script> <!-- Validator.js - Bootstrap plugin that validates forms -->
    <script src="js/scripts.js"></script> <!-- Custom scripts -->

</body>
</html>


<?php

if(isset($_POST['Cadastrar'])){

include_once("config.php");

    $categoria = $_POST["categoria"];

    $sql = "INSERT INTO categoria (categoria) VALUES ('$categoria')";

    if (mysqli_query($conn, $sql)) {
    echo "<script>alert('Dados cadastrados!'); window.location = 'principal.php';</script>";

    }else{
     echo "Deu erro: " . $sql . "<br>" . mysqli_error($conn);
    }



}




if(isset($_POST['Deletar'])){

include_once("config.php");

    $categoria = $_POST["categoria"];

    $sql = "DELETE FROM categoria WHERE id = '$categoria'";
    $sql2 = "DELETE FROM perguntas WHERE categoria = '$categoria'";


    if (mysqli_query($conn, $sql)) {
    mysqli_query($conn, $sql2);
    echo "<script>alert('Dados Deletados!'); window.location = 'principal.php';</script>";

    }else{
     echo "Deu erro: " . $sql . "<br>" . mysqli_error($conn);
    }



}


?>

