<?php
session_start();
include_once("config.php");

$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);

if(!empty($id)){
	$result_pergunta = "DELETE FROM perguntas WHERE id='$id'";
	$resultado_pergunta = mysqli_query($conn, $result_pergunta);

	if(mysqli_affected_rows($conn)){
		
		echo "<script>window.confirm('Dados cadastrados!'); window.location = 'principal.php';</script>";
	}else{
		echo "Deu erro: " . $sql . "<br>" . mysqli_error($conn);
	}
}
?>
