<?php

function dadosUser($login){

	include "config.php";
	$sql = "SELECT * FROM usuario1 WHERE usuario = '$login'";
	$query = $conn->query($sql);
	$dados = $query->fetch_array();


	 return array($dados['nome'],$dados['adm']);
}


function dadosAlterar($id){
include "config.php";
$result_pergunta = "SELECT * FROM perguntas WHERE id = '$id'";
$resultado_pergunta = mysqli_query($conn, $result_pergunta);
$rows_pergunta = mysqli_fetch_assoc($resultado_pergunta);

	return array(

		$rows_pergunta['id'],
		$rows_pergunta['categoria'],
		$rows_pergunta['pergunta'],
		$rows_pergunta['resposta']

	);

}

 
function contador($login){
	$servidor = '156.67.72.201';
$usuario = 'u748436382_portal_m';
$senha = 'Devmis@1';
$banco = 'u748436382_portal_mitra';
	$mysqli = new mysqli($servidor, $usuario, $senha, $banco);

	$sql = "INSERT INTO contador (login, data_acesso) VALUES ('$login', date_add(now(), interval -3 hour));";
	$query = $mysqli->query($sql);
}



?>