<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
        <!-- Text Logo - Use this if you don't have a graphic logo -->
        <!-- <a class="navbar-brand logo-text page-scroll" href="index.html">Evolo</a> -->

        <!-- Image Logo -->
        <a class="navbar-brand logo-image" href="index.php"></a>
        
        <!-- Mobile Menu Toggle Button -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-awesome fas fa-bars"></span>
            <span class="navbar-toggler-awesome fas fa-times"></span>
        </button>
        <!-- end of mobile menu toggle button -->

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav ml-auto">


                <li class="nav-item">
                    <a class="nav-link page-scroll" href="principal.php">Home <span class="sr-only">(current)</span></a>
                </li>

                <?php if($user[1]==1 or $login=="planejamento.fsa@tel.inf.br"){ //SO LIBERA SE FOR ADM ?>
               
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="categoria.php">Cadastrar Categoria</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="cadastro.php">Cadastrar Tópico</a>
                    </li>

                     <li class="nav-item">
                        <a class="nav-link page-scroll" href="add_user.php">Cadastrar Usuário</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="exportar.php">Exportar</a>
                    </li>
                    
                <?php } ?>

                <?php if($user[1]==2 and $login<> 'planejamento.fsa@tel.inf.br'){ //SO LIBERA SE FOR ADM ?>


                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="cadastro.php">Cadastrar Tópico</a>
                    </li>

                <?php } ?>

                <?php if($user[1] == 0 && $login == 'staff_claro'){ //SO LIBERA SE FOR ADM ?>


                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="exportar.php">Exportar</a>
                    </li>

                <?php } ?>

                <li class="nav-item">
                    <a class="nav-link page-scroll" href="../index.php">Sair</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link page-scroll" href="#contact"></a>
                </li>
            </ul>
            
        </div>
    </nav> <!-- end of navbar -->
    <!-- end of navigation -->