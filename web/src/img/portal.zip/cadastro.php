<?php
session_start();
$login = $_SESSION['login'];

if ($login == "") {

  echo "<script language='javascript'>
  alert('Ops! Por favor, logue novamente.')
  </script>";
  echo "<script type='text/javascript'>
  window.location='index.php';
  </script>";
}
?>
<!doctype html>
<html lang="pt">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="_css/boot.css">
  <link rel="stylesheet" href="_css/pg.css">

  <link rel="stylesheet" href="_css/all.css">
  <link rel="stylesheet" href="_css/solid.css">
  <link rel="stylesheet" href="_css/brands.css">
  <link rel="stylesheet" href="_css/menu.css">

  <script src="_js/all.js"> </script>
  <script src="_js/brands.js"> </script>
  <script src="_js/solid.js"> </script>
  <script src="_js/sw.js"></script>

  <title>Mitra Portal</title>
</head>

<body>




  <div style="background:#176086;width: 100%;height: 10px;margin-bottom: 10px"></div>
  <div class="container-fluid">
    <div class="row">
      <div class="col-2" style="text-align: center">
        <!--MENU E LOGOS-->
        <?php include "menu.php"; ?>
      </div>
      <div class="col-10">


        <form style="width: 80%;margin:0 auto;margin-top: 20px" enctype="multipart/form-data" method="post">
          <h1>Adicione as informações</h1><br>
          <div>
            <h3 style="text-align: right;margin-top: -20px;color: red;font-weight: bold;font-size: 12px">
              <a href="#" data-toggle="modal" data-target="#exampleModal">
                Deletar Categoria
              </a> |
              <a href="#" data-toggle="modal" data-target="#exampleModal2">
                Deletar Tópico
              </a>
            </h3>
          </div>
          <div class="form-group row">
            <label for="staticEmail" class="col-sm-2 col-form-label" style="text-align: center">Categoria</label>
            <div class="col-sm-10">
              <select class="form-control" name="cp1" required>
                <option value="">-</option>
                <?php
                include "_scripts/config.php";
                $sql = "SELECT * FROM base_categoria WHERE status = 'ATIVO'  ORDER BY categoria ASC";
                $query = $mysqli->query($sql);
                while ($dados = $query->fetch_array()) {
                  echo '<option value="' . utf8_encode($dados['id']) . '">' . $dados['categoria'] . '</option>';
                }
                ?>
              </select>
            </div>
          </div>
          <div class="form-group row">
            <label for="inputPassword" class="col-sm-2 col-form-label" style="text-align: center">Título da Postagem</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="cp2" id="inputPassword" required>
            </div>
          </div>
          <div class="form-group row">
            <label for="inputPassword" class="col-sm-2 col-form-label" style="text-align: center">Postagem</label>
            <div class="col-sm-10">
              <textarea name="cp3" class="form-control" required></textarea>
            </div>
          </div>
          <div class="form-group row">
            <label for="inputPassword" class="col-sm-2 col-form-label" style="text-align: center">Arquivo</label>
            <div class="col-sm-10">
              <input type="file" id="inputArquivo" name="arquivo">
            </div>
          </div>

          <div class="form-group row">
            <div class="col-sm-12" style="text-align: center">
              <input type="submit" class="btn btn-primary" value="POSTAR" name="enviar">
            </div>
          </div>
        </form>



      </div>
    </div>
  </div>





  <!-- Modal Deletar Tópico -->
  <form method="post" action="">
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Selecione o item para deletar<br>
              <span style="font-size: 12px"> Ao deletar, os subtópoicos assiciados vão ser deletados.</span>
            </h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body" style="color: #000;font-size: 14px;width: 100% !important">


            <?php
            include "_scripts/config.php";
            $sql = "SELECT * FROM base_categoria WHERE status = 'ATIVO'  ORDER BY categoria ASC";
            $query = $mysqli->query($sql);
            while ($dados = $query->fetch_array()) {
              //echo '<option value="' . utf8_encode($dados['id']) . '">' .$dados['categoria'] . '</option>';              
            ?>


              <form action="" method="post">
                <input type="hidden" name="id" value="<?php echo $dados['id']; ?>">
                <div class="row">
                  <div class="col-sm-8" style="text-align: center;padding-top:10px"><?php echo $dados['categoria']; ?></div>
                  <div class="col-sm-4" style="text-align: center;padding-top:10px ">
                    <input type="submit" class="btn btn-danger" value="Deletar" name="deletar">
                  </div>
                </div>

              <?php } ?>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-primary" data-dismiss="modal">Fechar</button>
          </div>
        </div>
      </div>
    </div>
  </form>
  <!-- FIM MODAL -->










  <!-- Modal Deletar Subtopico -->
  <form method="post" action="">
    <div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Selecione o item para deletar</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body" style="color: #000;font-size: 14px;width: 100% !important">


            <?php
            include "_scripts/config.php";
            $sql = "SELECT * FROM base ORDER BY titulo ASC";
            $query = $mysqli->query($sql);
            while ($dados = $query->fetch_array()) {
            ?>


              <form action="" method="post">
                <input type="hidden" name="id" value="<?php echo $dados['id']; ?>">
                <div class="row">
                  <div class="col-sm-3" style="text-align: center;padding-top:10px">
                    <?php echo $dados['titulo']; ?>
                  </div>
                  <div class="col-sm-6" style="text-align: center;padding-top:10px">
                    <?php echo $dados['informe']; ?>
                  </div>
                  <div class="col-sm-2" style="text-align: center;padding-top:10px ">
                    <input type="submit" class="btn btn-danger" value="Deletar" name="deletar2">
                  </div>
                </div>

              <?php } ?>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-primary" data-dismiss="modal">Fechar</button>
          </div>
        </div>
      </div>
    </div>
    <input type="text" name="login" value="<?php echo $login; ?>">
  </form>
  <!-- FIM MODAL -->











  <script src="_js/jquery.js"></script>
  <script src="_js/bundle.js"></script>



</body>

</html>



<?php

if (isset($_POST['enviar'])) {
  include "_scripts/config.php";

  $cp1 = $_POST['cp1'];
  $cp2 = $_POST['cp2'];
  $cp3 = $_POST['cp3'];
  $login = $_POST['login'];



  //TRATATIVA DA IMAGEM

  // Pasta onde o arquivo vai ser salvo
  $_UP['pasta'] = 'uploads/';

  // Tamanho máximo do arquivo (em Bytes)
  $_UP['tamanho'] = 1024 * 1024 * 2; // 2Mb

  // Array com as extensões permitidas
  $_UP['extensoes'] = array('jpg', 'png', 'gif', 'xls', 'xlsx', 'docx', 'pdf');

  // Renomeia o arquivo? (Se true, o arquivo será salvo como .jpg e um nome único)
  $_UP['renomeia'] = false;

  // Array com os tipos de erros de upload do PHP
  $_UP['erros'][0] = 'Não houve erro';
  $_UP['erros'][1] = 'O arquivo no upload é maior do que o limite do PHP';
  $_UP['erros'][2] = 'O arquivo ultrapassa o limite de tamanho especifiado no HTML';
  $_UP['erros'][3] = 'O upload do arquivo foi feito parcialmente';
  $_UP['erros'][4] = 'Não foi feito o upload do arquivo';


  if ($_FILES['arquivo']['error'] == 4) {

    $nome_final = "";
  } else {



    // Verifica se houve algum erro com o upload. Se sim, exibe a mensagem do erro
    if ($_FILES['arquivo']['error'] != 0) {
      die("Não foi possível fazer o upload, erro:" . $_UP['erros'][$_FILES['arquivo']['error']]);
      exit; // Para a execução do script
    }

    // Caso script chegue a esse ponto, não houve erro com o upload e o PHP pode continuar

    // Faz a verificação da extensão do arquivo
    $extensao = strtolower(end(explode('.', $_FILES['arquivo']['name'])));
    if (array_search($extensao, $_UP['extensoes']) === false) {
      echo "Por favor, envie arquivos com as seguintes extensões: jpg, png ou gif";
      exit;
    }

    // Faz a verificação do tamanho do arquivo
    if ($_UP['tamanho'] < $_FILES['arquivo']['size']) {
      echo "O arquivo enviado é muito grande, envie arquivos de até 2Mb.";
      exit;
    }

    // O arquivo passou em todas as verificações, hora de tentar movê-lo para a pasta

    // Primeiro verifica se deve trocar o nome do arquivo
    if ($_UP['renomeia'] == true) {
      // Cria um nome baseado no UNIX TIMESTAMP atual e com extensão .jpg
      $nome_final = md5(time()) . '.jpg';
    } else {
      // Mantém o nome original do arquivo
      $nome_final = $_FILES['arquivo']['name'];
    }


    if (move_uploaded_file($_FILES['arquivo']['tmp_name'], $_UP['pasta'] . $nome_final)) {
      // Upload efetuado com sucesso, exibe uma mensagem e um link para o arquivo

      //echo "Upload efetuado com sucesso!";
      // echo '<a href="' . $_UP['pasta'] . $nome_final . '">Clique aqui para acessar o arquivo</a>';
    } else {
      // Não foi possível fazer o upload, provavelmente a pasta está incorreta
      //$a = 1;
    }
  }

  $sql = "INSERT INTO base (categoria,titulo,informe,arquivo,login) VALUES ('$cp1','$cp2','$cp3','$nome_final','$login')";
  $query = $mysqli->query($sql);
  if ($query) {
?>

    <script language='javascript'>
      swal({
        icon: "success",
        text: "Salvo com Sucesso",
        type: "success"
      }).then(okay => {
        if (okay) {
          window.location.href = "cadastro.php";
        }
      });
    </script>

  <?php } else { ?>

    <script language='javascript'>
      swal({
        text: "Houve erro na conexão! Informe ao MIS",
        icon: "error",
      });
    </script>


  <?php }
}


















if (isset($_POST['deletar'])) {
  include "_scripts/config.php";

  $id = $_POST['id'];


  $sql = "DELETE FROM base_categoria WHERE id = '$id'"; //VERIFICAMOS SE O LOGIN EXISTE
  $query = $mysqli->query($sql);

  $sql2 = "DELETE FROM categoria WHERE categoria = '$id'"; //VERIFICAMOS SE O LOGIN EXISTE
  $query2 = $mysqli->query($sql2);

  if ($query) { ?>

    <script language='javascript'>
      swal({
        icon: "success",
        text: "Deletado conforme solicitado",
        type: "success"
      }).then(okay => {
        if (okay) {
          window.location.href = "cadastro.php";
        }
      });
    </script>

  <?php } else { //CASO O LOGIN NÃO EXISTA 
  ?>

    <script language='javascript'>
      swal({
        icon: "error",
        text: "Ops! Houve um erro!",
        type: "success"
      }).then(okay => {
        if (okay) {
          window.location.href = "cadastro.php";
        }
      });
    </script>


  <?php }
}









if (isset($_POST['deletar2'])) {
  include "_scripts/config.php";

  $id = $_POST['id'];


  $sql = "DELETE FROM base WHERE id = '$id'"; //VERIFICAMOS SE O LOGIN EXISTE
  $query = $mysqli->query($sql);

  if ($query) { ?>

    <script language='javascript'>
      swal({
        icon: "success",
        text: "Deletado conforme solicitado",
        type: "success"
      }).then(okay => {
        if (okay) {
          window.location.href = "cadastro.php";
        }
      });
    </script>

  <?php } else { //CASO O LOGIN NÃO EXISTA 
  ?>

    <script language='javascript'>
      swal({
        icon: "error",
        text: "Ops! Houve um erro!",
        type: "success"
      }).then(okay => {
        if (okay) {
          window.location.href = "cadastro.php";
        }
      });
    </script>


<?php }
}









?>