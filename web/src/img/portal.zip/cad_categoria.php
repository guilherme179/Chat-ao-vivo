<?php
session_start();
$login = $_SESSION['login'];

if($login==""){

  echo "<script language='javascript'>
  alert('Ops! Por favor, logue novamente.')
  </script>";
  echo "<script type='text/javascript'>
  window.location='index.php';
  </script>";
}

?>
<!doctype html>
<html lang="pt">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="_css/boot.css">
    <link rel="stylesheet" href="_css/pg.css">

    <link rel="stylesheet" href="_css/all.css">
    <link rel="stylesheet" href="_css/solid.css">
    <link rel="stylesheet" href="_css/brands.css">
    <link rel="stylesheet" href="_css/menu.css">

    <script src="_js/all.js"> </script>
    <script src="_js/brands.js"> </script>
    <script src="_js/solid.js"> </script>
    <script src="_js/sw.js"></script>

    <title>Mitra Portal</title>
</head>
<body>




<div style="background:#176086;width: 100%px;height: 10px;margin-bottom: 10px"></div>
    <div class="container-fluid">

        <div class="row">
            <div class="col-2" style="text-align: center"><!--MENU E LOGOS-->
              <?php include "menu.php"; ?>
            </div>
            <div class="col-10">


                <form style="width: 80%;margin:0 auto;margin-top: 20px" enctype="multipart/form-data" method="post">
                    <h1>Cadastre as Informações</h1><br>
                    <div class="form-group row">
                        <label for="staticEmail" class="col-sm-2 col-form-label" style="text-align: center">Categoria</label>
                        <div class="col-sm-10">
                             <input type="text" class="form-control" name="cp1" id="inputPassword" required>
                        </div>
                    </div>                    

                    <div class="form-group row">
                        <div class="col-sm-12" style="text-align: center">
                            <input type="submit" class="btn btn-primary" value="POSTAR" name="enviar">
                        </div>
                    </div>
                </form>



            </div>
        </div>
    </div>

        <script src="_js/jquery.js"></script>
        <script src="_js/bundle.js"></script>


</body>
</html>



<?php

if(isset($_POST['enviar'])){
include "_scripts/config.php";

$cp1 = $_POST['cp1'];


    $sql = "INSERT INTO base_categoria (categoria) VALUES ('$cp1')";
    $query = $mysqli->query($sql);

    if($query){
    ?>        

      <script language='javascript'>
       swal({ 
         icon:"success",
         text: "Salvo com Sucesso",
         type: "success"}).then(okay => {
           if (okay) {
            window.location.href = "index.php";
          }
        });
      </script>

    <?php } else { ?>

      <script language='javascript'>
       swal({
        text:"Houve erro na conexão! Informe ao MIS",
        icon:"error",
      });
      </script>


    <?php } 



}



?>