$(document).ready(function() {
  $('#cidade').select2();
});
  