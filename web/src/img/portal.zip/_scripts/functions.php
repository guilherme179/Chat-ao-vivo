<?php

function perfil($login){

	include "_scripts/config.php";
	$sql = "SELECT tipo FROM login WHERE login = '$login'";
	$query = $mysqli->query($sql);
	$dados = $query->fetch_array();
	  
	return $dados['tipo'];
}


function qtdeEvento($login){

	include "_scripts/config.php";
	$sql = "SELECT evento FROM base_evento WHERE login = '$login'";
	$query = $mysqli->query($sql);
	$total = $query->num_rows;


	 return $total-1;
}


function resultadoConsolidado($login){

	include "_scripts/config.php";
	$sql = "SELECT * FROM base_indicadores WHERE login = '$login'";
	$query = $mysqli->query($sql);
	$dados = $query->fetch_array();


	 return array($dados['rechamada'],$dados['tmo'],$dados['transferencia'],$dados['indevidos'],$dados['efet_cancelamento'],$dados['efet_migracao'],$dados['abs'],$dados['produtividade']);
}












?>