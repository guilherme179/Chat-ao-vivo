<?php
$servidor = '156.67.72.201';
$usuario = 'u748436382_portal_m';
$senha = 'Devmis@1';
$banco = 'u748436382_portal_mitra';

//Criar a conexao
$conn = mysqli_connect($servidor, $usuario, $senha, $banco);

?>