<?php
session_start();
$login = $_SESSION['login'];
$busq = $_GET['busq'];  

if($login==""){

  echo "<script language='javascript'>
  alert('Ops! Por favor, logue novamente.')
  </script>";
  echo "<script type='text/javascript'>
  window.location='index.php';
  </script>";
}

?>
<!doctype html>
<html lang="pt">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="_css/boot.css">
    <link rel="stylesheet" href="_css/pg.css">

    <link rel="stylesheet" href="_css/all.css">
    <link rel="stylesheet" href="_css/solid.css">
    <link rel="stylesheet" href="_css/brands.css">
    <link rel="stylesheet" href="_css/menu.css">

    <script src="_js/all.js"> </script>
    <script src="_js/brands.js"> </script>
    <script src="_js/solid.js"> </script>
    <script src="_js/sw.js"></script>

    <title>Mitra Portal</title>
</head>
<body>




<div style="background:#176086;width: 100%px;height: 10px;margin-bottom: 10px"></div>
    <div class="container-fluid">

        <div class="row">
            <div class="col-2" style="text-align: center"><!--MENU E LOGOS-->
              <?php include "menu.php"; ?>
            </div>
            <div class="col-10">





              <div class="content">
                    <h1>Mitra Portal</h1>

                    <!-- __________________________ SECTIONS ___________________________ --> 

                    <?php
                        include "_scripts/config.php";
                        $sql2 = "SELECT *
                        FROM base
                        WHERE informe LIKE '%$busq%'";
                        $query2 = $mysqli->query($sql2);
                        while ($dados2 = $query2->fetch_array()) {

                        $idd = $dados2['id'];

                    ?>

                    
                    <div style="margin-top: 10px">
                        <input type="checkbox" id="question<?php echo $idd; ?>" name="q"  class="questions">
                        <div class="plus">+</div>
                        <label for="question<?php echo $idd; ?>" class="question">
                            <?php echo $dados2['titulo']; ?>
                        </label>
                        <div class="answers">
                            <p><?php echo $dados2['informe']; ?></p>
                            
                            <?php if($dados2['arquivo']<>""){ ?>

                                <img class="img-fluid" src="uploads/<?php echo $dados2['arquivo']; ?>">

                            <?php } ?>

                        </div>
                    </div>

                    <?php }//FECHAMENTO DA EXIBIÇÃO DE TÍTULO ?>
                    





                    </div>






















              
            </div>
        </div>

    </div>

        <script src="_js/jquery.js"></script>
        <script src="_js/bundle.js"></script>


</body>
</html>



<?php

if(isset($_POST['enviar'])){
include "_scripts/config.php";

$cp1 = $_POST['cp1'];


    $sql = "INSERT INTO base_categoria (categoria) VALUES ('$cp1')";
    $query = $mysqli->query($sql);

    if($query){
    ?>        

      <script language='javascript'>
       swal({ 
         icon:"success",
         text: "Salvo com Sucesso",
         type: "success"}).then(okay => {
           if (okay) {
            window.location.href = "index.php";
          }
        });
      </script>

    <?php } else { ?>

      <script language='javascript'>
       swal({
        text:"Houve erro na conexão! Informe ao MIS",
        icon:"error",
      });
      </script>


    <?php } 



}



?>