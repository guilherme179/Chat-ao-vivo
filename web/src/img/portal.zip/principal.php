<?php 
include "head.php";
?>
<body data-spy="scroll" data-target=".fixed-top">
    

    
<?php include "menu.php" ?>

    <!-- Header -->
    <header id="header" class="header">
        <div class="header-content">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="text-container" style="margin-top: 20px">
                            <h1><span class="turquoise">
                                <img class="img-thumbnail" src="images/portal_mitra.png" style="border:0px #fff solid;margin-left:-30px">
                            </span></h1>
                            <p class="p-large" style="margin-top: -40px">Não deixe a falta de informações impactar seu trabalho. Fique por dentro das atualizações de processos e informações de intermitências sistêmicas aqui.</p>                    
                            
                            <form class="navbar-form navbar-left" method="POST" action="pesquisar.php">
                                <div class="form-group">
                                  <input type="text" class="form-control" placeholder="Digite aqui" name="pesquisar" required>
                                </div>

                                <input class="btn-solid-lg page-scroll" type="submit" value="Pesquisar">
                                <a class="btn-solid-lg page-scroll" href="pesquisar.php">Ver todos</a>
                            </form>
                            
                            
                        </div> <!-- end of text-container -->                        
                        
                </div> <!-- end of row -->
                <div class="col-lg-6">
                    <div class="image-container">
                        <img class="img-fluid" src="images/details-2-office-team-work.svg" alt="alternative">
                    </div> <!-- end of image-container -->
                </div> <!-- end of col -->

            </div> <!-- end of container -->
        </div> <!-- end of header-content -->
    </header> <!-- end of header -->
    <!-- end of header -->
    






<?php include "footer.php" ?>

<div class="modal fade" id="exemplomodal" tabindex="-1" role="dialog" aria-
 labelledby="myLargeModalLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="gridSystemModalLabel">&nbsp;</h4>
            </div>
            <div class="modal-body">
                <img src="images/ImagemPoupUp.jpg" class="img-fluid">

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
    </div>
</div>
    	
    <!-- Scripts -->
    <script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
    <script src="js/popper.min.js"></script> <!-- Popper tooltip library for Bootstrap -->
    <script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
    <script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
    <script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
    <script src="js/jquery.magnific-popup.js"></script> <!-- Magnific Popup for lightboxes -->
    <script src="js/validator.min.js"></script> <!-- Validator.js - Bootstrap plugin that validates forms -->
    <script src="js/scripts.js"></script> <!-- Custom scripts -->

    <script type="text/javascript">
        $(document).ready(function() {
            $('#exemplomodal').modal('show');
        })
    </script>
</body>
</html>